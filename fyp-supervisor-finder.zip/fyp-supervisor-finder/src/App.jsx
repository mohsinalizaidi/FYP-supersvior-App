import React from "react";
import Home from "./homeViews/Home";

function App() {
  return (
    <div className="min-h-screen bg-gray-100 p-4">
      <Home />
    </div>
  );
}

export default App;
